export const url = process.env.REACT_APP_API
console.log('url:', url)